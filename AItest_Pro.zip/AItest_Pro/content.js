
let isEnabled = false;
let isOverlayHidden = false;
let isShieldApplied = false;

chrome.storage.local.get("enabled", (data) => {
    isEnabled = data.enabled;
    if (isEnabled) activateShieldV14();
});

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "toggle") {
        isEnabled = msg.state;
        if (isEnabled) activateShieldV14();
        else location.reload();
    }
});

function activateShieldV14() {
    if (isShieldApplied) return; 
    isShieldApplied = true;

    console.clear = () => {};
    Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
    Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });

    const stopEvent = (e) => {
        if (isEnabled) {
            e.stopImmediatePropagation();
            return false;
        }
    };

    ['blur', 'focusout', 'visibilitychange', 'mouseleave', 'mouseout', 'resize', 'contextmenu', 'copy', 'paste', 'cut', 'selectstart'].forEach(evt => {
        window.addEventListener(evt, stopEvent, true);
        document.addEventListener(evt, stopEvent, true);
    });

    window.addEventListener('keydown', (e) => {
        if (!isEnabled) return;

        if (e.altKey && (e.key.toLowerCase() === 's' || e.code === 'KeyS')) {
            e.stopImmediatePropagation(); e.preventDefault();
            captureAndSolve();
            return;
        }
        if (e.altKey && (e.key.toLowerCase() === 'h' || e.code === 'KeyH')) {
            e.stopImmediatePropagation(); e.preventDefault();
            toggleOverlay();
            return;
        }

        const allowed = ['0','1','2','3','4','5','6','7','8','9','Enter','Backspace','Tab','Escape','Delete','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','F1','F2','F3','F4','F5','F6','F7','F8','F9','F10','F11','F12'];
        
        if (allowed.includes(e.key) && !e.altKey && !e.ctrlKey && !e.metaKey) {
            return; 
        }

        e.stopImmediatePropagation();
        e.preventDefault();
    }, true);

    window.addEventListener('keyup', stopEvent, true);
    window.addEventListener('keypress', stopEvent, true);

    const p_nop = () => Promise.resolve();
    [Element.prototype, document, document.documentElement].forEach(obj => {
        ['requestFullscreen', 'webkitRequestFullscreen', 'mozRequestFullScreen', 'msRequestFullscreen'].forEach(m => {
            if (obj && obj[m]) obj[m] = p_nop;
        });
    });

    setInterval(() => {
        if (isEnabled && (document.fullscreenElement || document.webkitFullscreenElement)) {
            (document.exitFullscreen || document.webkitExitFullscreen || (()=>{}))();
        }
    }, 100);
}

function toggleOverlay() {
    isOverlayHidden = !isOverlayHidden;
    const el = document.getElementById("ai-stealth-final-v14");
    if (el) el.style.display = isOverlayHidden ? "none" : "block";
}

async function captureAndSolve() {
    if (!isEnabled) return;
    let overlay = document.getElementById("ai-stealth-final-v14");
    if (!overlay) {
        overlay = document.createElement("div");
        overlay.id = "ai-stealth-final-v14";
        overlay.style = "position:fixed; bottom:5px; left:5px; z-index:2147483647; padding:5px 8px; background:rgba(255,255,255,0.01); color:#888; border-radius:3px; font-size:10px; font-family:monospace; pointer-events:none; max-width:300px; max-height:100px; overflow:hidden;";
        document.body.appendChild(overlay);
    }
    overlay.innerText = "..";
    overlay.style.display = isOverlayHidden ? "none" : "block";
    
    chrome.runtime.sendMessage({ action: "capture" }, (response) => {
        if (response && response.answer) overlay.innerText = response.answer;
    });
}
