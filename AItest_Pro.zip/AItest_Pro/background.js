const API_KEYS = [
    "AIzaSyCfoCT1FZz3hZ0Jp2ZLUs1dhmgW53MGKvY",
"AIzaSyCmTQZ6gCyUQu4ptjZDeK8qMHmPTLIkD54",
"AIzaSyANQPaN5I51HdI0v-OKuWjJl1xnDPz_39A",
"AIzaSyAk0GyPeG1saTx4vU6VeKT9t8pDznZhOFg",
"AIzaSyCwL--Gu9pXHxXMQBwrI0tjvW6veOvDV9M",
"AIzaSyBSI0q7ICArf_G5fkorrvdkLCLic_RRmnA",
"AIzaSyDhMpyDcZCDjhHX0YToc-1t0oBj3RKcibM",
"AIzaSyBOHKCDFSTgfBEuUmrJpE_GBao8fHHoyUU"
];
const GEMINI_MODEL = "gemini-2.5-flash"; // Free akkauntlar uchun eng barqaror model

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "capture") {
        chrome.tabs.captureVisibleTab(null, { format: "png" }, async (dataUrl) => {
            if (chrome.runtime.lastError || !dataUrl) {
                sendResponse({ answer: "" });
                return;
            }
            const answer = await tryAllKeys(dataUrl);
            sendResponse({ answer: answer });
        });
        return true;
    }
});

async function tryAllKeys(base64Image) {
    for (let key of API_KEYS) {
        try {
            const answer = await askGemini(base64Image, key);
            if (answer && answer !== "Error") {
                return answer;
            }
        } catch (e) {
            continue; // Limit tugasa yoki xato bo'lsa, keyingi kalitga o'tadi
        }
    }
    return "LIM";
}

async function askGemini(base64Image, apiKey) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`;

    const body = {
        contents: [{
            parts: [
                { text: "Sen fizika, matematika va ingliz tili ekspertisan; savolni tegishli ilmiy qonunlar, formulalar yoki grammatika qoidalari (kerak bo'lsa internetdan izlanib) asosida yech va agar to'g'ri javob variantlarda bo'lsa, faqat variant harfini (A, B, C, D) yoz, ortiqcha so'z qo'shma, agar to'g'ri javob variantlarda bo'lmasa, variant yoniga ? belgisini qo'shib qo'y, hech qachon javobsiz qoldirma." },
                { inline_data: { mime_type: "image/png", data: base64Image.split(",")[1] } }
            ]
        }],
        generationConfig: {
            temperature: 0.1,
            maxOutputTokens: 50
        }
    };

    try {
        const res = await fetch(url, {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        if (!res.ok) throw new Error(`API Error: ${res.status}`);

        const data = await res.json();
        if (data.candidates && data.candidates[0].content) {
            return data.candidates[0].content.parts[0].text.trim();
        }
        return "Error";
    } catch (e) {
        throw e;
    }
}
