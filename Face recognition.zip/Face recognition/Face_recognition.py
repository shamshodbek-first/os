import cv2
import face_recognition
import os
import pickle
import asyncio
from datetime import datetime, date
from aiogram import Bot

TELEGRAM_TOKEN = '' # Bot tokene '' ni ichiga tashlanadi
CHAT_ID = '' #  Bot tokene '' ni ichiga tashlanadi
bot = Bot(token=TELEGRAM_TOKEN)
# Vaqt chegarasi
starthour,startminute,endhour,endminute=[11,45,12,15] # bu yerda 2 vaqt oraligi ichida royhatga olish : 11:45 dan 12 : 15
known_face_encodings = []
known_face_names = []

student_images = ['ali.jpg','vali.jpg']  # Har bir o‘quvchining rasmi
student_names = ['Ali Aliyev', 'Vali Valiyev']  # Mos ism-familiyalar

for img_path, name in zip(student_images, student_names):
    if not os.path.exists(img_path):
        print(f"Rasm topilmadi: {img_path}")
        continue
    img = face_recognition.load_image_file(img_path)
    encodings = face_recognition.face_encodings(img)
    if len(encodings) == 0:
        print(f"Yuz topilmadi: {img_path}")
        continue
    known_face_encodings.append(encodings[0])
    known_face_names.append(name)

# Har kungi tekshiruv uchun 1 marta saqlash
ATTENDANCE_FILE = 'attendance.pkl'

def load_attendance():
    if os.path.exists(ATTENDANCE_FILE):
        with open(ATTENDANCE_FILE, 'rb') as f:
            data = pickle.load(f)
            if data['date'] == date.today():
                return data['attendance']
    return set()

def save_attendance(attendance):
    with open(ATTENDANCE_FILE, 'wb') as f:
        pickle.dump({'date': date.today(), 'attendance': attendance}, f)

attendance = load_attendance()

async def send_telegram_message(name):
    now = datetime.now()
    text = f"{now.strftime('%Y-%m-%d %H:%M:%S')} - {name} darsga keldi!"
    try:
        await bot.send_message(chat_id=CHAT_ID, text=text)
    except Exception as e:
        print(f"Telegram xabari yuborilmadi: {e}")

video_capture = cv2.VideoCapture(0)
if not video_capture.isOpened():
    print("Kamera ochilmadi!")
    exit(1)

process_this_frame = True

def is_time_between(start_hour, start_minute, end_hour, end_minute):
    now = datetime.now()
    start = now.replace(hour=start_hour, minute=start_minute, second=0, microsecond=0)
    end = now.replace(hour=end_hour, minute=end_minute, second=0, microsecond=0)
    if start <= end:
        return start <= now < end
    else:
        return start <= now or now < end

try:
    while True:
        if is_time_between(starthour,startminute,endhour,endminute):
            ret, frame = video_capture.read()
            if not ret:
                print("Kamera kadri olinmadi!")
                continue

            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
            rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

            if process_this_frame:
                face_locations = face_recognition.face_locations(rgb_small_frame)
                face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
                face_names = []
                for face_encoding in face_encodings:
                    matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.5)
                    name = "Unknown"
                    if True in matches:
                        first_match_index = matches.index(True)
                        name = known_face_names[first_match_index]
                        if name != "Unknown" and name not in attendance:
                            attendance.add(name)
                            save_attendance(attendance)
                            asyncio.run(send_telegram_message(name))
                    face_names.append(name)
            process_this_frame = not process_this_frame

            if 'face_locations' in locals():
                for (top, right, bottom, left), name in zip(face_locations, face_names):
                    top *= 4
                    right *= 4
                    bottom *= 4
                    left *= 4
                    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                    cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

            cv2.imshow('Face Recognition', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            cv2.waitKey(60000)

except KeyboardInterrupt:
    pass
finally:
    video_capture.release()
    cv2.destroyAllWindows()
